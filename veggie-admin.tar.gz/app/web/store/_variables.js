/* vuex state */
export const state = {

}

/* vuex getters */
export const getters = {
  token: state => state.user.token
}
