<template lang="pug">
  div 1
</template>

<script>
export default {
  name: 'Home',
  data () {
    return {
      // msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<style lang="stylus">

</style>
