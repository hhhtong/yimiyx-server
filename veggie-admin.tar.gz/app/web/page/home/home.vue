<style lang="stylus">
@import './home';
</style>
<template>
  <div class="home-main">
    首页
  </div>
</template>

<script>
export default {
  name: 'home',
  data() {
    return {
    }
  }
}
</script>
