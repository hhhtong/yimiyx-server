<template>
  <div>
    <h1>采购明细</h1>
  </div>
</template>

<script>
export default {
  name: 'purchase-manage__caigou-list'
}
</script>