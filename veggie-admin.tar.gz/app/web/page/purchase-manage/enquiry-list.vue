<style lang="stylus">
</style>

<template lang="pug">
  Layout(:style="{height: '100%'}" class="avf")
    Layout(:style="{height: '100%'}")
      Content(:style="{margin: '0 20px 88px', background: '#fff', height: '100%'}")
        | Content
      //- Footer(:style="{position: 'fixed', bottom: 0, width: '100%'}") Footer
    //- Sider(reverse-arrow collapsible) Sider
</template>

<script>
export default {
  name: 'purchase-manage__enquiry-list',

  data() {
    return {

    }
  },

  methods: {

  }
}
</script>
