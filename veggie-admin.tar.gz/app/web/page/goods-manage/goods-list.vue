<template>

</template>

<script>
export default {
  name: 'goods-list'
}
</script>
