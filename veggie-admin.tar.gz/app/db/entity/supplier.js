"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const typeorm_1 = require("typeorm");
const lodash_1 = require("lodash");
let Supplier = class Supplier {
};
__decorate([
    typeorm_1.PrimaryGeneratedColumn(),
    __metadata("design:type", Number)
], Supplier.prototype, "id", void 0);
__decorate([
    typeorm_1.Column('tinyint', { length: 1, default: 2 }),
    __metadata("design:type", Number)
], Supplier.prototype, "level", void 0);
__decorate([
    typeorm_1.Column('varchar', { name: lodash_1.snakeCase('supplierName'), length: 50, default: '' }),
    __metadata("design:type", String)
], Supplier.prototype, "supplierName", void 0);
__decorate([
    typeorm_1.Column('varchar', { name: lodash_1.snakeCase('linkmanName'), length: 10, default: '' }),
    __metadata("design:type", String)
], Supplier.prototype, "linkmanName", void 0);
__decorate([
    typeorm_1.Column('varchar', { length: 20, default: '' }),
    __metadata("design:type", String)
], Supplier.prototype, "tel", void 0);
__decorate([
    typeorm_1.Column('varchar', { name: lodash_1.snakeCase('areaCode'), length: 50, default: '' }),
    __metadata("design:type", String)
], Supplier.prototype, "areaCode", void 0);
__decorate([
    typeorm_1.Column('varchar', { name: lodash_1.snakeCase('areaName'), length: 100, default: '' }),
    __metadata("design:type", String)
], Supplier.prototype, "areaName", void 0);
__decorate([
    typeorm_1.Column('varchar', { length: 50, default: '' }),
    __metadata("design:type", String)
], Supplier.prototype, "address", void 0);
__decorate([
    typeorm_1.Column('tinyint', { name: lodash_1.snakeCase('supplierType'), length: 1, default: 0 }),
    __metadata("design:type", Number)
], Supplier.prototype, "supplierType", void 0);
__decorate([
    typeorm_1.Column('char', { name: lodash_1.snakeCase('payType'), length: 10, default: '' }),
    __metadata("design:type", String)
], Supplier.prototype, "payType", void 0);
__decorate([
    typeorm_1.Column('varchar', { name: lodash_1.snakeCase('accountNo'), length: 24, default: '' }),
    __metadata("design:type", String)
], Supplier.prototype, "accountNo", void 0);
__decorate([
    typeorm_1.Column('varchar', { name: lodash_1.snakeCase('bankName'), length: 10, nullable: true }),
    __metadata("design:type", String)
], Supplier.prototype, "bankName", void 0);
__decorate([
    typeorm_1.Column('char', { name: lodash_1.snakeCase('bankUsername'), length: 10, nullable: true }),
    __metadata("design:type", String)
], Supplier.prototype, "bankUsername", void 0);
__decorate([
    typeorm_1.Column('varchar', { name: lodash_1.snakeCase('bankAddress'), length: 50, nullable: true }),
    __metadata("design:type", String)
], Supplier.prototype, "bankAddress", void 0);
__decorate([
    typeorm_1.Column('varchar', { length: 150, default: '[]' }),
    __metadata("design:type", String)
], Supplier.prototype, "category", void 0);
__decorate([
    typeorm_1.Column('datetime', { name: lodash_1.snakeCase('createdAt'), nullable: true }),
    __metadata("design:type", Date)
], Supplier.prototype, "createdAt", void 0);
__decorate([
    typeorm_1.Column('tinyint', { name: lodash_1.snakeCase('isDelete'), default: 0 }),
    __metadata("design:type", Number)
], Supplier.prototype, "isDelete", void 0);
Supplier = __decorate([
    typeorm_1.Entity(lodash_1.snakeCase('Supplier'))
], Supplier);
exports.Supplier = Supplier;
