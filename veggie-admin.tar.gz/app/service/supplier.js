"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const egg_1 = require("egg");
const supplier_1 = require("../db/entity/supplier");
class SupplierService extends egg_1.Service {
    async query({ page, rows }) {
        const log = this.app.logger;
        const db = await this.ctx.db;
        const repo = db.getRepository(supplier_1.Supplier);
        try {
            const [list, total] = await repo
                .createQueryBuilder('supplier')
                .where('supplier.is_delete != 1')
                .orderBy('supplier.created_at', 'DESC')
                .skip((page - 1) * rows)
                .take(rows)
                .getManyAndCount();
            log.debug('供货商列表:', list);
            await db.close();
            return { list, total };
        }
        catch (e) {
            log.error(e.message);
            await db.close();
        }
    }
    async insert(rowData) {
        const log = this.app.logger;
        const db = await this.ctx.db;
        const supplier = new supplier_1.Supplier();
        for (const key in rowData) {
            if (rowData.hasOwnProperty(key)) {
                supplier[key] = rowData[key];
            }
        }
        try {
            await db.manager.save(supplier);
            log.info('新增一条供货商记录：', supplier);
            await db.close();
        }
        catch (e) {
            log.error(e.message);
            await db.close();
        }
    }
    async update(id, rowData) {
        const log = this.app.logger;
        const db = await this.ctx.db;
        const repo = db.getRepository(supplier_1.Supplier);
        try {
            await repo.updateById(id, rowData);
            log.info('更新一条供货商记录：', rowData);
            await db.close();
        }
        catch (e) {
            log.error(e.message);
            await db.close();
        }
    }
}
exports.default = SupplierService;
