declare var EASY_ENV_IS_NODE: boolean;
declare var EASY_ENV_IS_BROWSER: boolean;
declare var process : {
  env: {
    NODE_ENV: string
  }
}