'use strict'
Object.defineProperty(exports, '__esModule', { value: true })
const js_cookie_1 = require('js-cookie')
const user = {
  state: {},
  mutations: {
    logout (state, vm) {
      js_cookie_1.default.remove('user')
      js_cookie_1.default.remove('password')
      js_cookie_1.default.remove('access')
      // 恢复默认样式
      let themeLink = document.querySelector('link[name="theme"]')
      themeLink.setAttribute('href', '')
      // 清空打开的页面等数据，但是保存主题数据
      let theme = ''
      if (localStorage.theme) {
        theme = localStorage.theme
      }
      localStorage.clear()
      if (theme) {
        localStorage.theme = theme
      }
    }
  }
}
exports.default = user
// # sourceMappingURL=user.js.map