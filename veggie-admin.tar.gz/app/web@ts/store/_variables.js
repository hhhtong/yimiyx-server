'use strict'
Object.defineProperty(exports, '__esModule', { value: true })
/* vuex state */
exports.state = {}
/* vuex getters */
exports.getters = {}
// # sourceMappingURL=_variables.js.map