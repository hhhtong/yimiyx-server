'use strict'
Object.defineProperty(exports, '__esModule', { value: true })
const client_1 = require('client')
// import serverRender from 'server';
const vue_1 = require('vue')
const vuex_router_sync_1 = require('vuex-router-sync')
const app_vue_1 = require('./app.vue')
const iview_1 = require('iview')
require('iview/dist/styles/iview.css')
const store_1 = require('store')
const index_1 = require('router/index')
const router_1 = require('router/router')
const vue_virtual_scroller_1 = require('vue-virtual-scroller')
vue_1.default.use(iview_1.default)
vue_1.default.component('virtual-scroller', vue_virtual_scroller_1.VirtualScroller)
vuex_router_sync_1.sync(store_1.default, index_1.default)
const options = Object.assign({ base: '/app' }, app_vue_1.default, { router: index_1.default,
  store: store_1.default,
  data: {
    currentPageName: ''
  },
  mounted () {
    this.currentPageName = this.$route.name
    // 显示打开的页面的列表
    this.$store.commit('setOpenedList')
    this.$store.commit('initCachepage')
    // 权限菜单过滤相关
    this.$store.commit('updateMenulist')
  },
  created () {
    const tagsList = []
    router_1.appRouter.map((item) => {
      if (item.children.length <= 1) {
        tagsList.push(item.children[0])
      } else {
        tagsList.push(...item.children)
      }
    })
    this.$store.commit('setTagsList', tagsList)
  } })
exports.default = client_1.default(options)
// export default EASY_ENV_IS_NODE ? serverRender(options) : clientRender(options);
// # sourceMappingURL=app.js.map