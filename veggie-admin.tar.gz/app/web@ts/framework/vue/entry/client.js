'use strict'
Object.defineProperty(exports, '__esModule', { value: true })
const vue_1 = require('vue')
require('../component')
require('../directive')
require('../filter')
function default_1 (options) {
  vue_1.default.prototype.$http = require('axios')
  if (options.store) {
    options.store.replaceState(window.__INITIAL_STATE__ || {})
  } else if (window.__INITIAL_STATE__) {
    options.data = Object.assign(window.__INITIAL_STATE__, options.data && options.data())
  }
  const app = new vue_1.default(options)
  app.$mount('#app')
}
exports.default = default_1
// # sourceMappingURL=client.js.map