'use strict'
Object.defineProperty(exports, '__esModule', { value: true })
const vue_1 = require('vue')
require('../component')
require('../directive')
require('../filter')
function render (options) {
  if (options.store && options.router) {
    return (context) => {
      options.router.push(context.state.url)
      const matchedComponents = options.router.getMatchedComponents()
      if (!matchedComponents) {
        return Promise.reject({ code: '404' })
      }
      return Promise.all(matchedComponents.map((component) => {
        if (component.preFetch) {
          return component.preFetch(options.store)
        }
        return null
      })).then(() => {
        context.state = options.store.state
        return new vue_1.default(options)
      })
    }
  }
  return (context) => {
    const VueApp = vue_1.default.extend(options)
    const app = new VueApp({ data: context.state })
    return new Promise((resolve) => {
      resolve(app)
    })
  }
}
exports.default = render
// # sourceMappingURL=server.js.map