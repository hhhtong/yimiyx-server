'use strict'
Object.defineProperty(exports, '__esModule', { value: true })
const vue_1 = require('vue')
const iview_1 = require('iview')
const util_1 = require('../libs/util')
const vue_router_1 = require('vue-router')
const router_1 = require('./router')
// import Home from './modules/home'
// const routes = [...Home]
const mode = process.env.EGG_SERVER_ENV === 'prop' ? 'history' : 'hash'
vue_1.default.use(vue_router_1.default)
// 路由配置
const RouterConfig = { mode, routes: router_1.routes }
const router = new vue_router_1.default(RouterConfig)
router.beforeEach((to, from, next) => {
  iview_1.default.LoadingBar.start()
  util_1.default.title(to.meta.title)
  next()
})
router.afterEach((to) => {
  iview_1.default.LoadingBar.finish()
  window.scrollTo(0, 0)
})
exports.default = router
// # sourceMappingURL=index.js.map