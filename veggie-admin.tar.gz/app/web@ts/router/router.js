'use strict'
Object.defineProperty(exports, '__esModule', { value: true })
const Main_vue_1 = require('@/page/Main.vue')
// in development-env not use lazy-loading, because lazy-loading too many pages will cause webpack hot update too slow. so only in production use lazy-loading;
const $import = file => {
  if (process.env.EGG_SERVER_ENV !== 'prod') {
    return require('@/page/' + file + '.vue').default
  } else {
    return () => Promise.resolve().then(() => require('@/page/' + file + '.vue'))
  }
}
/**
* hidden: true                   if `hidden:true` will not show in the sidebar(default is false)
* redirect: noredirect           if `redirect:noredirect` will no redirct in the breadcrumb
* name:'router-name'             the name is used by <keep-alive> (must set!!!)
* meta : {
    title: 'title'               the name show in submenu and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar,
  }
**/
// 不作为Main组件的子页面展示的页面单独写，如下
exports.loginRouter = {
  path: '/login',
  name: 'login',
  meta: {
    title: 'Login - 登录'
  },
  component: $import('login')
}
exports.page404 = {
  path: '/*',
  name: 'error-404',
  meta: {
    title: '404-页面不存在'
  },
  component: $import('error-page/404')
}
exports.page403 = {
  path: '/403',
  meta: {
    title: '403-权限不足'
  },
  name: 'error-403',
  component: $import('error-page/403')
}
exports.page500 = {
  path: '/500',
  meta: {
    title: '500-服务端错误'
  },
  name: 'error-500',
  component: $import('error-page/500')
}
exports.locking = {
  path: '/locking',
  name: 'locking',
  component: $import('main-components/lockscreen/components/locking-page')
}
// 作为Main组件的子页面展示但是不在左侧菜单显示的路由写在otherRouter里
exports.otherRouter = {
  path: '/',
  name: 'otherRouter',
  redirect: '/home',
  component: Main_vue_1.default,
  children: [
    { path: 'home', title: '工作台', name: 'home_index', component: $import('home/home') },
    { path: 'ownspace', title: '个人中心', name: 'ownspace_index', component: $import('own-space/own-space') },
    { path: 'message', title: '消息中心', name: 'message_index', component: $import('message/message') }
  ]
}
// 作为Main组件的子页面展示并且在左侧菜单显示的路由写在appRouter里
exports.appRouter = [
  {
    path: '/purchase-manage',
    icon: 'ios-folder',
    name: 'purchase-manage',
    title: '采购管理',
    component: Main_vue_1.default,
    children: [
      {
        path: 'supplier-list',
        icon: 'ios-paper-outline',
        name: 'purchase-manage__supplier-list',
        title: '供货商管理',
        component: $import('purchase-manage/supplier-list')
      },
      {
        path: 'enquiry-list',
        icon: 'ios-list-outline',
        name: 'purchase-manage__enquiry-list',
        title: '询价明细',
        component: $import('purchase-manage/enquiry-list')
      },
      {
        path: 'caigou-list',
        icon: 'ios-list-outline',
        name: 'purchase-manage__caigou-list',
        title: '采购明细',
        component: $import('purchase-manage/caigou-list')
      }
    ]
  },
  // {
  //   path: '/page',
  //   icon: 'ios-paper',
  //   title: 'Page',
  //   name: 'page',
  //   component: Main,
  //   children: [
  //     {
  //       path: 'index',
  //       title: 'Page',
  //       name: 'page_index',
  //       component: $import('page/page')
  //     }
  //   ]
  // },
  {
    path: '/access',
    icon: 'key',
    name: 'access',
    title: '权限管理',
    component: Main_vue_1.default,
    children: [
      { path: 'index', title: '权限管理', name: 'access_index', component: $import('access/access') }
    ]
  },
  // {
  //   path: '/access-test',
  //   icon: 'lock-combination',
  //   title: '权限测试页',
  //   name: 'accesstest',
  //   access: 0,
  //   component: Main,
  //   children: [
  //     { path: 'index', title: '权限测试页', name: 'accesstest_index', access: 0, component: $import('access/access-test') }
  //   ]
  // },
  {
    path: '/error-page',
    icon: 'android-sad',
    title: '错误页面',
    name: 'errorpage',
    component: Main_vue_1.default,
    children: [
      { path: 'index', title: '错误页面', name: 'errorpage_index', component: $import('error-page/error-page') }
    ]
  }
]
// 所有上面定义的路由都要写在下面的routers里
exports.routes = [
  exports.loginRouter,
  exports.otherRouter,
  exports.locking,
  ...exports.appRouter,
  exports.page500,
  exports.page403,
  exports.page404
]
// # sourceMappingURL=router.js.map