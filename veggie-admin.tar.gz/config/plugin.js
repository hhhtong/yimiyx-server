"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = require("path");
exports.static = true;
exports.vuessr = {
    enable: true,
    package: 'egg-view-vue-ssr'
};
exports.typeorm = {
    enable: true,
    path: path_1.join(__dirname, '../libs/plugin/egg-typeorm')
};
