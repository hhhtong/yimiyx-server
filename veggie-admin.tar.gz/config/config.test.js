"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = (app) => {
    const exports = {};
    return exports;
};
