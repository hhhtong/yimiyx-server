"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = require("path");
// import { readFileSync } from 'fs';
exports.default = (app) => {
    const exports = {};
    // exports.siteFile = {
    //   '/favicon.ico': readFileSync(join(app.baseDir, 'app/web/asset/images/favicon.ico'))
    // };
    exports.cluster = {
        listen: {
            port: 7001,
            hostname: '127.0.0.1',
        }
    };
    exports.security = {
        csrf: {
            ignoreJSON: true,
        }
    };
    exports.view = {
        cache: false
    };
    exports.vuessr = {
        layout: path_1.join(app.baseDir, 'app/web/template/layout.html')
    };
    exports.logger = {
        consoleLevel: 'DEBUG',
        dir: path_1.join(app.baseDir, 'logs')
    };
    exports.static = {
        prefix: '/public/',
        dir: path_1.join(app.baseDir, 'public')
    };
    exports.keys = '123456';
    exports.middleware = [
        'access'
    ];
    return exports;
};
