

import { EggAppConfig } from 'egg';

export default (app : EggAppConfig) => {
  const exports : any = {};

  return exports;
};
